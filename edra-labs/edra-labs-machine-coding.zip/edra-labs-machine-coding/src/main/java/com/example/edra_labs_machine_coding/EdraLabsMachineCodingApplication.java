package com.example.edra_labs_machine_coding;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EdraLabsMachineCodingApplication {

	public static void main(String[] args) {
		SpringApplication.run(EdraLabsMachineCodingApplication.class, args);
	}

}
